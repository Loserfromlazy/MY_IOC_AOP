package com.learn.pojo;

/**
 * <p>
 * BankInfo
 * </p>
 *
 * @author Yuhaoran
 * @since 2021/11/11
 */
public class BankInfo {

    private Integer id;
    private String name;
    private Integer money;
    private String cardNo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    @Override
    public String toString() {
        return "BankInfo{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", money=" + money +
                ", cardNo='" + cardNo + '\'' +
                '}';
    }
}
