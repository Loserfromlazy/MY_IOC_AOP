package com.learn.service;

import java.io.IOException;

/**
 * <p>
 * AccountService
 * </p>
 *
 * @author Yuhaoran
 * @since 2021/11/16
 */
public interface AccountService {
    void transfer(String fromCardNo, String toCardNo, int money) throws Exception;
}
