package com.learn.service.Impl;

import com.learn.dao.AccountDao;
import com.learn.pojo.BankInfo;
import com.learn.service.AccountService;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.InputStream;

/**
 * <p>
 * AccountServiceImpl
 * </p>
 *
 * @author Yuhaoran
 * @since 2021/11/16
 */
public class AccountServiceImpl implements AccountService {


    @Override
    public void transfer(String fromCardNo, String toCardNo, int money) throws Exception {
        System.out.println(fromCardNo+"  "+toCardNo+"   "+money);
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSession sqlSession = sqlSessionFactoryBuilder.build(resourceAsStream).openSession();
        AccountDao mapper = sqlSession.getMapper(AccountDao.class);
        System.out.println(mapper);
        BankInfo fromNo = mapper.findByCardNo(fromCardNo);
        BankInfo toNo = mapper.findByCardNo(toCardNo);
        System.out.println(fromNo);
        System.out.println(toNo);
        fromNo.setMoney(fromNo.getMoney() - money);
        toNo.setMoney(toNo.getMoney() + money);
        System.out.println(fromNo);
        System.out.println(toNo);
        int update = mapper.updateByCardNo(fromNo);
        System.out.println("更新了" + update + "条数据");
        int update1 = mapper.updateByCardNo(toNo);
        System.out.println("更新了" + update1 + "条数据");
        sqlSession.commit();
        sqlSession.close();
    }
}
