package com.learn.dao;

import com.learn.pojo.BankInfo;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 * AccountDao
 * </p>
 *
 * @author Yuhaoran
 * @since 2021/11/16
 */
public interface AccountDao {
    @Select("select * from bank_info where card_no = #{cardNo}")
    @Result(column = "card_no",property = "cardNo")
    BankInfo findByCardNo(String cardNo);

    @Update("update bank_info set name =#{name},money=#{money} where card_no=#{cardNo}")
    @Result(column = "card_no",property = "cardNo")
    int updateByCardNo(BankInfo bankInfo);
}
